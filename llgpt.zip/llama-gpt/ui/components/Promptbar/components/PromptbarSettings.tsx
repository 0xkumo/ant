import { FC } from 'react';

interface Props {}

export const PromptbarSettings: FC<Props> = () => {
  return <div></div>;
};
